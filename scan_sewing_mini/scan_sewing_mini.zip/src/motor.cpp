#include "motor.h"
using namespace PE;
StepperMotor::StepperMotor(){
    while(FAS_ConnectTCP(192,168,0,idX,idX) == FALSE){
        std::cout << "X Motor Connection Failed" << std::endl;
        Sleep(1000);
    }
	
	while(FAS_ConnectTCP(192,168,0,idY1,idY1) == FALSE){
        std::cout << "Y1 Motor Connection Failed" << std::endl;
        Sleep(1000);
    }

	while(FAS_ConnectTCP(192,168,0,idY2,idY2) == FALSE){
        std::cout << "Y2 Motor Connection Failed" << std::endl;
        Sleep(1000);
    }
	preDirX = -1;
	preDirY = -1;
	del_x = -0.003;
	del_y = -0.01;
    std::cout << "Successfully Connected" << std::endl;
}

StepperMotor::~StepperMotor(){
	//this->servoEnable(false);
    FAS_Close(idX);
	FAS_Close(idY1);
	FAS_Close(idY2);
}

void StepperMotor::clearAlarm(){
    FAS_ServoAlarmReset(idX);
	FAS_ServoAlarmReset(idY1);
	FAS_ServoAlarmReset(idY2);

	return;
}

void StepperMotor::setMotorParameter(int id, int ppr, int maxSpeed, int startSpeed, int accTime, int decTime, int orgSpeed, int orgSearchSpeed, int orgMethod){
    FAS_SetParameter(id, 0, ppr);
	FAS_SetParameter(id, 1, maxSpeed);
	FAS_SetParameter(id, 2, startSpeed);
	FAS_SetParameter(id, 3, accTime);
	FAS_SetParameter(id, 4, decTime);
	FAS_SetParameter(id, 14, orgSpeed);
	FAS_SetParameter(id, 15, orgSearchSpeed);
	FAS_SetParameter(id, 17, orgMethod);
	FAS_SetParameter(id, 18, 0);
	FAS_SetParameter(id, 25, 0);

    clearAlarm();
    return;
}

void StepperMotor::setValueCompensation(double xp, double xn, double yp, double yn){
	this->increXP = xp/1000.0;
	this->increXN = xn/1000.0;
	this->increYP = yp/1000.0;
	this->increYN = yn/1000.0;

	return;
}

int StepperMotor::servoEnable(bool enable) {
	int nRtn = 1;
	nRtn *= FAS_ServoEnable(idX, enable);
	nRtn *= FAS_ServoEnable(idY1, enable);
	nRtn *= FAS_ServoEnable(idY2, enable);
	return nRtn;
}

int StepperMotor::servoEnable(int id, bool enable){
    return FAS_ServoEnable(id, enable);
}

int StepperMotor::moveSingleAxis_mm(int id, double posAbs, double period){
    long pulseAbs = posAbs * mm_to_pulse;	// 1rev : 1mm -> 1/1000 rev : 1 micron
	int velocity = abs(pulseAbs	/ period);
	int nRtn;
    nRtn = FAS_MoveSingleAxisAbsPos(id, pulseAbs, 150000);

	return (nRtn == FMM_OK);

}

void StepperMotor::isMotioning(int id){
    EZISERVO_AXISSTATUS stAxisStatus;
    int nRtn;
    do{
        Sleep(1);
        nRtn = FAS_GetAxisStatus(id, &dwAxisStatus);
        stAxisStatus.dwValue = dwAxisStatus;
    }
    while(stAxisStatus.FFLAG_MOTIONING);
}

int StepperMotor::moveAxis_mm(double posX, double posY, double period) {
	int dirX, dirY;
	double posXtemp, posYtemp;
	posXtemp = posX;
	posYtemp = posY;
	// X compensation
	if (posX > prePosX){
		dirX = 1;
		xIncre += increXP * (dirX != preDirX);
	}
	else if (posX < prePosX){
		dirX = -1;
		xIncre -= increXN * (dirX != preDirX);
	}
	else dirX = 0;

	posX += xIncre;

	// Y compensation
	if (posY > prePosY){
		dirY = 1;
		yIncre += increYP * (dirY != preDirY);
	}
	else if (posY < prePosY){
		dirY = -1;
		yIncre -= increYN * (dirY != preDirY);
	}
	else dirY = 0;
	posY += yIncre;

	// Apply HW Limit constraint
	if (posX > 0) {
		posX = 0;
	}
	if (posX < -10.0) {
		posX = -10.0;
	}
	if (posY > 0) {
		posY = 0.0;
	}
	if (posY < -10.0) {
		posY = -10.0;
	}

	// Update previous commands
	prePosX = posXtemp;
	prePosY = posYtemp;
	if (dirX != 0) preDirX = dirX;
	if (dirY != 0) preDirY = dirY;

	// Actual actuation command
	int resX = this->moveSingleAxis_mm(idX, posX+del_x, period);
	int resY1 = this->moveSingleAxis_mm(idY1, posY+del_y, period);
	int resY2 = this->moveSingleAxis_mm(idY2, posY+del_y, period);
	std::cout << "Target: " << posXtemp << ", " << posYtemp << "  Command: ";
	std::cout << posX + del_x << ", " << posY+del_y << std::endl;
	if (resX == 1 && resY1 == 1 && resY2 == 1) return 1;
	else return 0;
}

int StepperMotor::limitPosSearchX() {
	if (FAS_MoveOriginSingleAxis(idX) != FMM_OK) {
		std::cout << "ERROR - MOTOR - motor " << 0 << " - limitPosSearch " << "\n";
		return -1;
	}

	std::cout << "Notification - motor " << 0 << " - limitPosSearch - Limit Search End" << "\n";

	return 1;
}

void StepperMotor::tmp() {
	DWORD dwInput;
	int nRtn;
	int iDir = 1;
	long lVelocityFast, lVelocitySlow;
	lVelocityFast = 1000;
	lVelocitySlow = 200;
	FAS_MoveVelocity(idY2, lVelocityFast, iDir);

	do {
		nRtn = FAS_GetIOInput(idY1, &dwInput);
	} while (!(dwInput & STEP_IN_BITMASK_LIMITP));

	FAS_MoveStop(idY2);

	Sleep(1000);

	FAS_MoveVelocity(idY2, lVelocitySlow, !iDir);

	do {
		nRtn = FAS_GetIOInput(idY1, &dwInput);
	} while (dwInput & STEP_IN_BITMASK_LIMITP);

	FAS_MoveStop(idY2);

}
int StepperMotor::limitPosSearchY(){
	DWORD dwInput;
	int nRtn;
	int iDir = 1;
	long lVelocityFast, lVelocitySlow;
	lVelocityFast = 4000;
	lVelocitySlow = 500;

	FAS_MoveVelocity(idY1, lVelocityFast, iDir);
	FAS_MoveVelocity(idY2, lVelocityFast, iDir);
	
	do{
		nRtn = FAS_GetIOInput(idY1, &dwInput);
	}
	while(!(dwInput & STEP_IN_BITMASK_LIMITP));
	FAS_MoveStop(idY1);
	FAS_MoveStop(idY2);

	Sleep(1000);

	FAS_MoveVelocity(idY1, lVelocitySlow, !iDir);
	std::cout << "back 1" << std::endl;
	FAS_MoveVelocity(idY2, lVelocitySlow, !iDir);
	std::cout << "back 2" << std::endl;
	
	do{
		nRtn = FAS_GetIOInput(idY1, &dwInput);
	}
	while(dwInput & STEP_IN_BITMASK_LIMITP);
	FAS_MoveStop(idY1);
	FAS_MoveStop(idY2);

	this->isMotioning(idY1);
	this->isMotioning(idY2);
	
	FAS_ClearPosition(idY1);
	FAS_ClearPosition(idY2);

	return 1;
}


int StepperMotor::limitPosSearch() {
	if (this->limitPosSearchX() == -1) {
		return -1;
	}
	if (this->limitPosSearchY() == -1) {
		return -1;
	}
	return 1;
}

int StepperMotor::emergencyStop(){
	FAS_EmergencyStop(idX);
	FAS_EmergencyStop(idY1);
	FAS_EmergencyStop(idY2);
	return 1;
}